package com.farhan.q4;

public class Address {
	String city;
	String state;
	String pinCode;
	@Override
	public String toString() {
		return "Address [city=" + city + ", state=" + state + ", pinCode=" + pinCode + "]";
	}
}
