package com.farhan.q3;

public class HatchBack extends Car{
	final int farePerKm = 15;
}
