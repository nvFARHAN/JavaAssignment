package com.farhan.q3;

public class Sedan extends Car {
	final int farePerKm = 20;
}
